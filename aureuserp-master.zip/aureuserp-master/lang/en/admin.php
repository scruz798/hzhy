<?php

return [
    'navigation' => [
        'dashboard'     => 'Dashboard',
        'contact'       => 'Contact',
        'sale'          => 'Sales',
        'purchase'      => 'Purchase',
        'invoice'       => 'Invoices',
        'accounting'    => 'Accounting',
        'inventory'     => 'Inventory',
        'maintenance'   => 'Maintenance',
        'manufacturing' => 'Manufacturing',
        'project'       => 'Project',
        'employee'      => 'Employees',
        'time-off'      => 'Time Off',
        'recruitment'   => 'Recruitments',
        'website'       => 'Website',
        'plugin'        => 'Plugins',
        'setting'       => 'Settings',
        'help'          => 'Help',
        'barcode'       => 'Barcode',
    ],
];
